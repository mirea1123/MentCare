public class Patients
{
  //Declare instance data
  private String First_name , Last_name;
 
  //Constructor
  public Patients(String First_name, String Last_name)
  {
    this.First_name = First_name;
    this.Last_name = Last_name;
  }
  //Setter for name
  public void setfirstname(String First_name)
  {
    this.First_name = First_name;
  }
  //Getter for name 
   public String getfirstname()
  {
    return this.First_name;
  }
   //Setter for name
   public void setlastname(String Last_name)
  {
    this.Last_name = Last_name;
  }
  //Getter for name 
   public String getlastname()
  {
    return this.Last_name;
  }
   
  //Print out
  public String toString()
  {
    return "New Patient Added -> First Name: "+First_name+ " Last Name: "+Last_name;
    
  }
  
}
    

    

