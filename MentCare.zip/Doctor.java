public class Doctor
{
  public static void main(String[] args) 
  { 
   
    Patients patient1 = new Patients("John","Smith");
    Patients patient2 = new Patients("N/A", "N/A");
    Patients patient3 = new Patients("N/A", "N/A");
    Patients patient4 = new Patients("N/A", "N/A");
    Patients patient5 = new Patients("N/A", "N/A");
    Patients patient6 = new Patients("N/A", "N/A");
    Patients patient7 = new Patients("N/A", "N/A");
    Patients patient8 = new Patients("N/A", "N/A");
    Patients patient9 = new Patients("N/A", "N/A");
    Patients patient10 = new Patients("N/A", "N/A");
    
    

    System.out.println(patient1);
  }
  
  
  
  
  
  
  
  
  
}
  